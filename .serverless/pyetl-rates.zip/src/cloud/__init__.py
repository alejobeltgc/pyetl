"""
Cloud module for AWS integrations.
"""
