"""
Configuration package.
"""

from .accounts_config import ACCOUNTS_CONFIG

__all__ = ['ACCOUNTS_CONFIG']
